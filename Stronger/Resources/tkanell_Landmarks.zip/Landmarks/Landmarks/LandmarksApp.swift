//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Theodore Kanell on 1/10/24.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
